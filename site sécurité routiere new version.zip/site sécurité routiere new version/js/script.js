$(document).ready(function(){
  $(".menu-hamburger").on("click", function(){
    $("nav ul").toggleClass("showing");
  });
});
